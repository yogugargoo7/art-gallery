import { getApp, getApps, initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";

const firebaseConfig = {
  apiKey: "AIzaSyDL6vDqoYIl3xUshM9iKTqCfoNGhJ8yLJ8",
  authDomain: "webapp-53751.firebaseapp.com",
  databaseURL: "https://webapp-53751-default-rtdb.firebaseio.com",
  projectId: "webapp-53751",
  storageBucket: "webapp-53751.appspot.com",
  messagingSenderId: "423980178881",
  appId: "1:423980178881:web:df5a9b22a49f37f97b6340"
};

const app = getApps.length > 0 ? getApp() : initializeApp(firebaseConfig);

const firestore = getFirestore(app);
const storage = getStorage(app);

export { app, firestore, storage };
